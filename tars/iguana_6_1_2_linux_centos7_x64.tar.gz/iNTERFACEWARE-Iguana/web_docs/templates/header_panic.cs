<?cs # vim: set syntax=html :?>

<div id="header">

<script type="text/javascript" src="<?cs var:iguana_version_js("/skinningwindow.js") ?>"></script>
<script type="text/javascript" src="<?cs var:iguana_version_js("/js/ajax/ajax.js") ?>"></script>


<header>
   <div>
     <a href="/dashboard.html"><img src="<?cs var:skin("/images/iguana_logo.png") ?>" class="iguana_logo"/></a>
     <span class="version">v. <?cs include:"version.cs" ?></span>
   </div>
   <nav>
      <span class="user">Welcome, &nbsp;<?cs var:CurrentUser ?></span>
           
   </nav>
</header>

       
         

<div class="breadcrumb">
</div>

</div>
